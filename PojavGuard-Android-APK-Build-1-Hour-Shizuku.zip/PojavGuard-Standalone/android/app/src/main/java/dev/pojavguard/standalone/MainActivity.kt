package dev.pojavguard.standalone

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Process
import rikka.shizuku.Shizuku
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipInputStream

private const val PREFS = "pojavguard_local"
private const val KEY_URI = "tree_uri"
private const val KEY_INVENTORY = "inventory_v2"
private const val KEY_BASELINED = "baseline_created"
private const val KEY_ALERTS = "alerts_v1"
private const val KEY_LAST_SCAN = "last_complete_scan_ms"
private const val KEY_BASELINE_URI = "baseline_tree_uri"
private const val KEY_SHIZUKU_INVENTORY = "shizuku_inventory_v1"
private const val KEY_SHIZUKU_LAST_SCAN = "shizuku_last_scan_ms"
private const val KEY_SHIZUKU_BASELINED = "shizuku_baseline_created" 
private const val SHIZUKU_PERMISSION_REQUEST = 4817
private const val CHECK_INTERVAL_MS = 30_000L
private const val RECENT_WINDOW_MS = 60 * 60 * 1000L

data class FileRecord(
    val path: String,
    val size: Long,
    val modified: Long,
    val sha256: String?
)
data class LocalAlert(val title: String, val detail: String, val time: Long)
data class ScanResult(
    val files: Map<String, FileRecord>,
    val complete: Boolean,
    val errors: List<String>,
    val modFindings: List<String>
)

class MainActivity : ComponentActivity() {
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_PERMISSION_REQUEST) {
            // Permission state is refreshed by the composable on resume / button interaction.
        }
    }
    override fun onStart() {
        super.onStart()
        Shizuku.addRequestPermissionResultListener(permissionListener)
    }
    override fun onStop() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onStop()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PojavGuardScreen() }
    }
}

@Composable
private fun PojavGuardScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    SideEffect { AppContextHolder.resolver = context.contentResolver }
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var treeUri by remember {
        mutableStateOf(prefs.getString(KEY_URI, null)?.let(Uri::parse))
    }
    var rootLabel by remember { mutableStateOf("No folder selected") }
    var inventory by remember { mutableStateOf(loadInventory(prefs)) }
    var alerts by remember { mutableStateOf(loadAlerts(prefs)) }
    var baselineCreated by remember { mutableStateOf(prefs.getBoolean(KEY_BASELINED, false)) }
    var status by remember { mutableStateOf("Select the Minecraft folder and create a baseline.") }
    var lastScan by remember { mutableStateOf(prefs.getLong(KEY_LAST_SCAN, 0L).takeIf { it > 0L }) }
    var scanning by remember { mutableStateOf(false) }
    var modFindings by remember { mutableStateOf(listOf<String>()) }
    var shizukuPath by remember { mutableStateOf("/storage/emulated/0/Android/data/net.kdt.pojavlaunch/files/.minecraft") }
    var shizukuStatus by remember { mutableStateOf(shizukuPermissionStatus()) }
    var shizukuScanning by remember { mutableStateOf(false) }
    var shizukuInventory by remember { mutableStateOf(loadShizukuInventory(prefs)) }
    var shizukuBaselined by remember { mutableStateOf(prefs.getBoolean(KEY_SHIZUKU_BASELINED, false)) }
    var shizukuLastScan by remember { mutableStateOf(prefs.getLong(KEY_SHIZUKU_LAST_SCAN, 0L).takeIf { it > 0L }) }

    LaunchedEffect(treeUri) {
        val uri = treeUri
        rootLabel = if (uri == null) "No folder selected"
        else DocumentFile.fromTreeUri(context, uri)?.name ?: "Selected folder"
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                val newUriString = uri.toString()
                val previousUriString = prefs.getString(KEY_URI, null)
                treeUri = uri
                prefs.edit().putString(KEY_URI, newUriString).apply()
                rootLabel = DocumentFile.fromTreeUri(context, uri)?.name ?: "Selected folder"
                if (previousUriString != newUriString) {
                    // A baseline belongs to one exact SAF tree. Never compare unrelated roots.
                    inventory = emptyMap()
                    baselineCreated = false
                    modFindings = emptyList()
                    lastScan = null
                    prefs.edit().remove(KEY_INVENTORY).remove(KEY_LAST_SCAN)
                        .putBoolean(KEY_BASELINED, false).putString(KEY_BASELINE_URI, newUriString).apply()
                    status = "New folder selected. Create a baseline for this folder before monitoring changes."
                } else {
                    // Re-selecting the same folder must not erase monitoring history.
                    status = "Same folder reselected. Existing baseline and alerts were preserved."
                }
            } catch (e: Exception) {
                status = "Android did not grant persistent folder access: ${e.message ?: "permission error"}"
            }
        }
    }

    suspend fun scanNow() {
        val uri = treeUri ?: run {
            status = "Select a folder first."
            return
        }
        scanning = true
        try {
            val root = DocumentFile.fromTreeUri(context, uri)
            if (root == null || !root.exists() || !root.isDirectory || !root.canRead()) {
                status = "Folder is unavailable or Android denied access. No deletion conclusions were made."
                return
            }

            val result = scanTree(root)
            val now = System.currentTimeMillis()

            if (!result.complete) {
                // Critical safety rule: never report missing files based on an incomplete scan.
                status = "INCOMPLETE SCAN: ${result.errors.size} access/listing problem(s). No files were marked deleted. Fix access and scan again."
                return
            }

            modFindings = result.modFindings
            if (!baselineCreated) {
                inventory = result.files
                baselineCreated = true
                saveInventory(prefs, inventory)
                prefs.edit().putBoolean(KEY_BASELINED, true).apply()
                lastScan = now
                prefs.edit().putLong(KEY_LAST_SCAN, now).putString(KEY_BASELINE_URI, uri.toString()).apply()
                status = "Baseline created successfully: ${result.files.size} accessible files recorded. Complete scans now check for missing/changed files every 30 seconds while the app remains active."
                return
            }

            val previous = inventory
            val missing = previous.keys - result.files.keys
            val added = result.files.keys - previous.keys
            val changed = result.files.keys.intersect(previous.keys).filter { path ->
                val old = previous[path]!!
                val new = result.files[path]!!
                old.size != new.size ||
                    (old.modified > 0L && new.modified > 0L && old.modified != new.modified) ||
                    (old.sha256 != null && new.sha256 != null && old.sha256 != new.sha256)
            }

            val newAlerts = mutableListOf<LocalAlert>()
            val previousScanAt = lastScan
            for (path in missing.sorted()) {
                val old = previous[path]!!
                val recentlyMissing = previousScanAt != null && now - previousScanAt <= RECENT_WINDOW_MS
                val windowNote = if (recentlyMissing) {
                    " It was present at the previous complete scan ${formatTime(previousScanAt ?: 0L)} (within the last 1 hour)."
                } else {
                    " The previous complete scan was more than 1 hour ago or its time is unknown."
                }
                newAlerts.add(
                    LocalAlert(
                        if (recentlyMissing) "FILE MISSING — RECENT CHANGE, VERIFY" else "FILE MISSING — VERIFY",
                        "File absent from the selected Minecraft folder: $path. Last observed file modification time: ${formatTime(old.modified)}. First detected missing at: ${formatTime(now)}.$windowNote Exact deletion time and cause are unknown; it may have been deleted, moved, renamed, or become inaccessible. Not proof of cheating.",
                        now
                    )
                )
            }
            for (path in changed.sorted()) {
                newAlerts.add(
                    LocalAlert(
                        "FILE CHANGED — REVIEW",
                        "Previously recorded file changed: $path. A normal game/mod update can cause this; review before drawing conclusions.",
                        now
                    )
                )
            }

            alerts = (newAlerts + alerts).take(500)
            saveAlerts(prefs, alerts)
            inventory = result.files
            saveInventory(prefs, inventory)
            lastScan = now
            prefs.edit().putLong(KEY_LAST_SCAN, now).putString(KEY_BASELINE_URI, uri.toString()).apply()
            status = "Complete scan: ${result.files.size} accessible files. Missing: ${missing.size}; changed: ${changed.size}; new: ${added.size}. Missing-file alerts stay in the log for review; alerts are not proof of cheating."
        } catch (e: SecurityException) {
            status = "Access denied by Android. No deletion conclusions were made."
        } catch (e: Exception) {
            status = "Scan failed safely: ${e.message ?: e.javaClass.simpleName}. Previous baseline was kept."
        } finally {
            scanning = false
        }
    }

    suspend fun scanShizukuRoot() {
        shizukuScanning = true
        try {
            shizukuStatus = shizukuPermissionStatus()
            if (!Shizuku.pingBinder()) {
                shizukuStatus = "Shizuku service is not running. Start Shizuku first, then grant PojavGuard permission."
                return
            }
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                shizukuStatus = "Shizuku permission not granted. Tap Grant Shizuku access first."
                return
            }
            val root = shizukuPath.trim()
            if (root.isEmpty() || !root.startsWith("/storage/")) {
                shizukuStatus = "Enter an absolute path under /storage/, such as the PojavLauncher Minecraft directory."
                return
            }
            val result = withContext(Dispatchers.IO) { scanViaShizuku(root) }
            if (!result.complete) {
                shizukuStatus = "Shizuku scan incomplete: ${result.errors.take(3).joinToString("; ")}. No missing-file alerts were generated."
                return
            }
            val now = System.currentTimeMillis()
            val previous = shizukuInventory
            if (!shizukuBaselined) {
                shizukuInventory = result.files
                saveShizukuInventory(prefs, shizukuInventory)
                shizukuBaselined = true
                prefs.edit().putBoolean(KEY_SHIZUKU_BASELINED, true).putLong(KEY_SHIZUKU_LAST_SCAN, now).apply()
                shizukuLastScan = now
                shizukuStatus = "Shizuku baseline created: ${result.files.size} files. Re-scan during the next hour to compare changes."
                return
            }
            val missing = previous.keys - result.files.keys
            val changed = previous.keys.intersect(result.files.keys).filter { path ->
                val old = previous[path]!!; val fresh = result.files[path]!!
                old.size != fresh.size || (old.modified > 0L && fresh.modified > 0L && old.modified != fresh.modified) ||
                    (old.sha256 != null && fresh.sha256 != null && old.sha256 != fresh.sha256)
            }
            val withinHour = shizukuLastScan != null && now - (shizukuLastScan ?: 0L) <= RECENT_WINDOW_MS
            val newAlerts = mutableListOf<LocalAlert>()
            for (path in missing.sorted()) {
                newAlerts.add(LocalAlert(
                    if (withinHour) "SHIZUKU FILE MISSING — VERIFY" else "SHIZUKU FILE MISSING — VERIFY (OUTSIDE WINDOW)",
                    "File absent from Shizuku-scanned root: $path. Last recorded modification: ${formatTime(previous[path]?.modified ?: 0L)}; absence detected: ${formatTime(now)}. Previous complete Shizuku scan was ${if (withinHour) "within 1 hour" else "more than 1 hour ago or unknown"}. Could be deleted, moved, renamed, or inaccessible; not proof of cheating.", now
                ))
            }
            for (path in changed.sorted()) newAlerts.add(LocalAlert("SHIZUKU FILE CHANGED — REVIEW", "File changed under Shizuku-scanned root: $path. Legitimate updates can cause this.", now))
            if (newAlerts.isNotEmpty()) {
                alerts = (newAlerts + alerts).take(500)
                saveAlerts(prefs, alerts)
            }
            shizukuInventory = result.files
            saveShizukuInventory(prefs, result.files)
            shizukuLastScan = now
            prefs.edit().putLong(KEY_SHIZUKU_LAST_SCAN, now).apply()
            shizukuStatus = "Complete Shizuku scan: ${result.files.size} files; missing ${missing.size}; changed ${changed.size}."
        } catch (e: Exception) {
            shizukuStatus = "Shizuku scan failed: ${e.message ?: e.javaClass.simpleName}. Existing baseline was kept."
        } finally {
            shizukuScanning = false
        }
    }

    LaunchedEffect(treeUri, baselineCreated) {
        while (treeUri != null) {
            delay(CHECK_INTERVAL_MS)
            if (treeUri != null && baselineCreated && !scanning) scanNow()
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                Surface(shadowElevation = 2.dp) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Text("PojavGuard Standalone", style = MaterialTheme.typography.titleLarge)
                        Text("Conservative local file monitor", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Minecraft folder", style = MaterialTheme.typography.titleLarge)
                            Text(rootLabel)
                            OutlinedButton(onClick = { picker.launch(treeUri) }, enabled = !scanning) {
                                Text("Choose folder")
                            }
                            Button(
                                onClick = { scope.launch { scanNow() } },
                                enabled = !scanning && treeUri != null,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (scanning) "Scanning…" else if (baselineCreated) "Scan now" else "Create baseline") }
                            Text(status, style = MaterialTheme.typography.bodyMedium)
                            Text("Last complete scan: ${lastScan?.let { formatTime(it) } ?: "Not yet in this session"}")
                            Text("Baseline files: ${inventory.size}")
                            Text(
                                "Automatic checks are best-effort while this app is open. Android may pause background work.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Optional Shizuku access", style = MaterialTheme.typography.titleLarge)
                            Text("Can provide broader shell-level file access on compatible devices after you install/start Shizuku and explicitly authorize PojavGuard. It is not root and cannot guarantee access to every path.", style = MaterialTheme.typography.bodySmall)
                            Text("Status: $shizukuStatus", style = MaterialTheme.typography.bodyMedium)
                            OutlinedButton(onClick = {
                                shizukuStatus = shizukuPermissionStatus()
                                if (!Shizuku.pingBinder()) {
                                    shizukuStatus = "Shizuku is not running. Install/start the official Shizuku service first."
                                } else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                                    shizukuStatus = "Permission granted. Enter the Pojav Minecraft path below and scan."
                                } else {
                                    Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST)
                                    shizukuStatus = "Permission request sent. Approve it in Shizuku, then scan again."
                                }
                            }, enabled = !shizukuScanning) { Text("Check / grant Shizuku access") }
                            OutlinedTextField(
                                value = shizukuPath, onValueChange = { shizukuPath = it },
                                label = { Text("Minecraft folder absolute path") },
                                supportingText = { Text("Default path is common, but verify your Pojav package/path. You may enter another accessible /storage path.") },
                                modifier = Modifier.fillMaxWidth(), singleLine = false
                            )
                            Button(onClick = { scope.launch { scanShizukuRoot() } }, enabled = !shizukuScanning, modifier = Modifier.fillMaxWidth()) {
                                Text(if (shizukuScanning) "Scanning with Shizuku…" else if (shizukuBaselined) "Scan Shizuku folder" else "Create Shizuku baseline")
                            }
                            Text("Last Shizuku scan: ${shizukuLastScan?.let { formatTime(it) } ?: "Never"} · Baseline files: ${shizukuInventory.size}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    Text("Mod / cheat indicators (${modFindings.size})", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Scans accessible files under the selected root, including version folders and mods. Indicators come from filenames and bounded JAR entry-name inspection; they are heuristics, not proof that a mod is malicious or active.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                items(modFindings) { finding ->
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("REVIEW INDICATOR", style = MaterialTheme.typography.titleMedium)
                            Text(finding)
                        }
                    }
                }
                item {
                    Text("Local file-change alerts (${alerts.size})", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Missing files are reported only after a complete scan. Alerts include the exact path and first-detected time; the 1-hour note refers to scan timing, not a proven deletion timestamp. Inaccessible/incomplete scans never produce deletion alerts.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                items(alerts) { alert ->
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(alert.title, style = MaterialTheme.typography.titleMedium)
                            Text(alert.detail)
                            Text(formatTime(alert.time), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                item {
                    Text(
                        "The app cannot prove who deleted a file or recover deletions that happened before the first baseline. It scans only the selected folder and files Android allows it to access. A renamed/moved file appears missing at its old path and new at its new path.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

private fun shizukuPermissionStatus(): String = try {
    when {
        !Shizuku.pingBinder() -> "Shizuku service not running"
        Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> "Shizuku permission granted"
        else -> "Shizuku permission not granted"
    }
} catch (e: Exception) { "Shizuku unavailable: ${e.javaClass.simpleName}" }

private fun scanViaShizuku(root: String): ScanResult {
    val files = linkedMapOf<String, FileRecord>()
    val errors = mutableListOf<String>()
    val safeRoot = "'" + root.replace("'", "'\\''") + "'"
    // The fixed script is passed to sh; the user path is shell-quoted. No file is executed.
    val script = """if [ ! -d $safeRoot ] || [ ! -r $safeRoot ]; then echo 'PG_ERROR:root_unreadable' >&2; exit 3; fi
find $safeRoot -type f -exec sh -c 'for f do s=${'$'}(stat -c %s "${'$'}f" 2>/dev/null) || { echo PG_STAT_ERROR >&2; continue; }; m=${'$'}(stat -c %Y "${'$'}f" 2>/dev/null) || { echo PG_STAT_ERROR >&2; continue; }; h=${'$'}(sha256sum "${'$'}f" 2>/dev/null | cut -d " " -f 1); printf "%s\t%s\t%s\t%s\n" "${'$'}f" "${'$'}s" "${'$'}m" "${'$'}h"; done' sh {} +"""
    val process = Shizuku.newProcess(arrayOf("sh", "-c", script), null, null)
    val output = process.inputStream.bufferedReader().use { it.readText() }
    val stderr = process.errorStream.bufferedReader().use { it.readText() }
    val exit = process.waitFor()
    if (exit != 0 || stderr.isNotBlank()) return ScanResult(emptyMap(), false, listOf("Shizuku shell could not completely read root (exit $exit). Check path and permissions. ${stderr.take(200)}"), emptyList())
    for (line in output.lineSequence()) {
        val parts = line.split('	')
        if (parts.size < 4) { if (line.isNotBlank()) errors.add("Unparsed file entry returned by shell"); continue }
        val fullPath = parts[0]
        val relative = fullPath.removePrefix(root.trimEnd('/') + "/").ifBlank { fullPath }
        val size = parts[1].toLongOrNull()
        if (size == null) { errors.add("Invalid size for $relative"); continue }
        val modified = (parts[2].toLongOrNull() ?: 0L) * 1000L
        val hash = parts[3].takeIf { it.matches(Regex("[0-9a-fA-F]{64}")) }
        files[relative] = FileRecord(relative, size, modified, hash)
    }
    return ScanResult(files, errors.isEmpty(), errors.take(100), emptyList())
}

private fun saveShizukuInventory(context: Context, inventory: Map<String, FileRecord>) {
    val arr = JSONArray()
    inventory.values.forEach { f -> arr.put(JSONObject().apply {
        put("path", f.path); put("size", f.size); put("modified", f.modified); put("sha256", f.sha256 ?: JSONObject.NULL)
    }) }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_SHIZUKU_INVENTORY, arr.toString()).apply()
}

private fun loadShizukuInventory(context: Context): Map<String, FileRecord> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SHIZUKU_INVENTORY, null) ?: return emptyMap()
    return try { val arr = JSONArray(raw); buildMap {
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); val path = o.getString("path");
            put(path, FileRecord(path, o.optLong("size"), o.optLong("modified"), if (o.isNull("sha256")) null else o.getString("sha256"))) }
    } } catch (_: Exception) { emptyMap() }
}

private fun scanTree(root: DocumentFile): ScanResult {
    val files = mutableMapOf<String, FileRecord>()
    val errors = mutableListOf<String>()
    val findings = mutableListOf<String>()

    fun walk(dir: DocumentFile, prefix: String, depth: Int) {
        if (depth > 40) {
            errors.add("Maximum folder depth reached at $prefix")
            return
        }
        if (!dir.canRead()) {
            errors.add("Folder not readable: $prefix")
            return
        }
        val children = try {
            dir.listFiles()
        } catch (e: Exception) {
            errors.add("Could not list $prefix: ${e.javaClass.simpleName}")
            return
        }
        for (child in children) {
            val name = child.name
            if (name == null) {
                errors.add("Entry with unknown name in $prefix")
                continue
            }
            val path = if (prefix.isEmpty()) name else "$prefix/$name"
            try {
                if (!child.exists()) {
                    errors.add("Entry disappeared during scan: $path")
                } else if (child.isDirectory) {
                    if (!child.canRead()) errors.add("Subfolder not readable: $path")
                    else walk(child, path, depth + 1)
                } else if (child.isFile) {
                    val hash = hashDocument(child.uri)
                    files[path] = FileRecord(path, child.length(), child.lastModified(), hash)

                    // Do not classify every JAR as suspicious. Only report explicit,
                    // conservative filename indicators and common mod metadata locations.
                    if (looksLikeKnownCheatName(name)) {
                        findings.add("$path — filename matches a known cheat-related name; review manually (not a verdict).")
                    }
                    if (name.endsWith(".jar", ignoreCase = true)) {
                        findings.addAll(inspectJarEntryNames(child.uri, path))
                    }
                }
            } catch (e: Exception) {
                errors.add("Could not inspect $path: ${e.javaClass.simpleName}")
            }
        }
    }

    walk(root, "", 0)
    return ScanResult(files, errors.isEmpty(), errors.take(200), findings.distinct().sorted())
}


private fun inspectJarEntryNames(uri: Uri, jarPath: String): List<String> {
    val findings = mutableListOf<String>()
    val resolver = AppContextHolder.resolver ?: return findings
    // Static inspection only: never loads or executes classes. Bounds limit CPU and zip-bomb exposure.
    val featureIndicators = listOf(
        "killaura", "reach", "autoclicker", "aimassist", "freecam", "scaffold",
        "triggerbot", "cheststealer", "velocity", "nofall", "packetfly", "disabler",
        "antibot", "targetstrafe", "criticalshits", "criticalhit", "blink"
    )
    try {
        resolver.openInputStream(uri)?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entries = 0
                var expandedBytes = 0L
                while (entries < 5000 && expandedBytes < 10L * 1024L * 1024L) {
                    val entry = zip.nextEntry ?: break
                    entries++
                    val entryName = entry.name.lowercase(Locale.ROOT)
                    if (!entry.isDirectory && featureIndicators.any { indicator ->
                            val base = entryName.substringAfterLast('/').substringBeforeLast('.')
                            base == indicator || base.startsWith("${indicator}module") || base.startsWith("${indicator}feature")
                        }) {
                        findings.add("$jarPath — archive entry '${entry.name}' matches a known cheat-feature name; review manually (not proof of use).")
                    }
                    val buffer = ByteArray(4096)
                    while (expandedBytes < 10L * 1024L * 1024L) {
                        val count = zip.read(buffer)
                        if (count <= 0) break
                        expandedBytes += count
                    }
                    if (expandedBytes >= 10L * 1024L * 1024L) break
                    zip.closeEntry()
                }
            }
        }
    } catch (_: Exception) {
        // Corrupt or unsupported archives remain inventoried by path/hash; do not turn this
        // heuristic inspection failure into a deletion flag or a cheating verdict.
    }
    return findings
}

private fun looksLikeKnownCheatName(name: String): Boolean {
    val n = name.lowercase(Locale.ROOT)
        .replace('_', '-')
        .replace(' ', '-')
    // Filename-only heuristic. These are review indicators, never a verdict.
    // Broad generic words such as "client", "hack", or "mod" are intentionally excluded.
    val indicators = listOf(
        "killaura", "kill-aura", "reachhack", "reach-hack", "silentaim", "silent-aim",
        "freecam", "free-cam", "autoclicker", "auto-clicker", "aimassist", "aim-assist",
        "cheatclient", "cheat-client", "meteor-client", "wurst-client", "impact-client",
        "liquidbounce", "aristois", "inertia-client", "raven-bplus", "raven-b+",
        "vestige", "rise-client", "novo-client", "sigma-client", "horion"
    )
    return indicators.any { n.contains(it) }
}

private fun hashDocument(uri: Uri): String? {
    return try {
        val digest = MessageDigest.getInstance("SHA-256")
        val resolver = AppContextHolder.resolver ?: return null
        resolver.openInputStream(uri).use { input ->
            if (input == null) return null
            val buffer = ByteArray(8192)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) {
        null
    }
}

private object AppContextHolder {
    var resolver: android.content.ContentResolver? = null
}

@Composable
private fun ResolverSetup() {
    val context = androidx.compose.ui.platform.LocalContext.current
    SideEffect { AppContextHolder.resolver = context.contentResolver }
}

private fun saveInventory(context: Context, inventory: Map<String, FileRecord>) {
    val arr = JSONArray()
    inventory.values.forEach { f ->
        arr.put(JSONObject().apply {
            put("path", f.path)
            put("size", f.size)
            put("modified", f.modified)
            put("sha256", f.sha256 ?: JSONObject.NULL)
        })
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit().putString(KEY_INVENTORY, arr.toString()).apply()
}

private fun loadInventory(context: Context): Map<String, FileRecord> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_INVENTORY, null)
        ?: return emptyMap()
    return try {
        val arr = JSONArray(raw)
        buildMap {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val path = o.getString("path")
                val hash = if (o.isNull("sha256")) null else o.getString("sha256")
                put(path, FileRecord(path, o.optLong("size"), o.optLong("modified"), hash))
            }
        }
    } catch (_: Exception) { emptyMap() }
}

private fun saveAlerts(context: Context, alerts: List<LocalAlert>) {
    val arr = JSONArray()
    alerts.forEach { a ->
        arr.put(JSONObject().apply {
            put("title", a.title)
            put("detail", a.detail)
            put("time", a.time)
        })
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit().putString(KEY_ALERTS, arr.toString()).apply()
}

private fun loadAlerts(context: Context): List<LocalAlert> {
    val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ALERTS, null)
        ?: return emptyList()
    return try {
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(LocalAlert(o.getString("title"), o.getString("detail"), o.optLong("time")))
            }
        }
    } catch (_: Exception) { emptyList() }
}

private fun formatTime(ms: Long): String =
    if (ms <= 0L) "unknown time"
    else SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ms))
