# PojavGuard Standalone (Android source project)

A local-only Android scanner for an explicitly selected Minecraft/PojavLauncher folder.

## Implemented behavior

- Uses Android's Storage Access Framework; the user chooses the root folder to scan.
- Optional Shizuku integration: checks the running service, requests explicit user authorization, and performs a separate shell-level inventory of a user-entered `/storage/...` root where Android/Shizuku permit access. The default path is only a suggestion and may differ by launcher/package/version.
- Shizuku inventory is stored separately from the SAF inventory and supports its own baseline, SHA-256 comparison, and one-hour missing/changed-file alerts. No root exploit or permission bypass is used; Shizuku must be installed, started, and authorized by the device owner.
- Recursively inventories accessible files under that root, including version-specific folders, `mods`, configs, and nested directories.
- Records relative paths, file sizes, modification times, and SHA-256 hashes where Android permits reading.
- Saves the first complete scan as a baseline and persists the inventory and alerts locally.
- Re-selecting the same folder preserves the existing baseline. Selecting a different folder resets the comparison baseline to prevent comparing unrelated folders.
- Rechecks every 30 seconds while the app is active and Android allows it to run.
- Creates missing-file alerts only after a complete scan. Incomplete scans do not produce deletion alerts.
- Missing-file alerts show the exact relative path, the file's last recorded modification time, the time the absence was first detected, and whether the previous complete scan was within the last 1 hour.
- Keeps a local alert history (up to 500 alerts) so alerts remain visible for later review.
- Flags selected known cheat-related filename patterns and inspects JAR entry names using bounded, static inspection. It never executes JAR code.
- Does not upload files, connect to a server, auto-ban, or claim that a heuristic finding proves cheating.

## Build

Open the `android/` directory in Android Studio with a JDK supported by Android Gradle Plugin 8.7.3 and Android SDK Platform 35 installed. Let Gradle sync, then build the `app` debug APK. The expected output is `android/app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have Android SDK/Gradle configured, so this source bundle is **not a compiled or device-tested APK**.

## Shizuku setup

1. Install Shizuku from its official distribution and start its service using the method supported by the device (typically wireless debugging on a non-rooted phone).
2. Open PojavGuard and tap **Check / grant Shizuku access**; approve the request in Shizuku.
3. Verify the actual Pojav Minecraft path for the installed launcher and enter it in the path field. The default `/storage/emulated/0/Android/data/net.kdt.pojavlaunch/files/.minecraft` is not guaranteed to match every installation.
4. Tap **Create Shizuku baseline**, then scan again to compare changes.

Shizuku access depends on the shell identity, Android release, OEM implementation, path, and service state. A failed or incomplete scan must not be interpreted as proof of deletion. This feature has not yet been compiled or device-tested in this environment.

## Important limits

- **Start monitoring before the period you want to audit.** The app cannot detect files deleted before the first baseline.
- A file absent from a later complete scan may have been deleted, moved, renamed, or become inaccessible. The scanner cannot prove who removed it or the exact deletion time. The “within the last 1 hour” note only describes the interval between successful scans.
- Checks run every 30 seconds only while the app remains active. Android can pause/suspend the app; a file deleted and restored between scans may be missed. For this reason, the app cannot guarantee capture of every deletion.
- The app can scan only the selected folder and files exposed by Android's folder picker. It cannot automatically inspect every Minecraft installation elsewhere on the phone.
- Cheat indicators are filename/JAR-entry-name heuristics. Legitimate mods can contain similarly named classes, and renamed/obfuscated/embedded cheats may not be identified. All findings are review indicators, not verdicts.
- A full recursive hash scan can take time and use battery on large folders.
